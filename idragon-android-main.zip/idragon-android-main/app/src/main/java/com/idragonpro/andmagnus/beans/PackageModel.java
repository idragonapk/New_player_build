package com.idragonpro.andmagnus.beans;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class PackageModel implements Serializable {

    @SerializedName("id")
    @Expose
    private long id;
    @SerializedName("subscription_status")
    @Expose
    private int subscriptionstatus;
    @SerializedName("Package")
    @Expose
    private String _package;
    @SerializedName("Description")
    @Expose
    private String description;
    @SerializedName("Price")
    @Expose
    private String price;
    @SerializedName("upgrade_price")
    @Expose
    private String upgradeprice;
    @SerializedName("mrp")
    @Expose
    private String mrp;
    @SerializedName("discount")
    @Expose
    private String discount;
    @SerializedName("sCode")
    @Expose
    private String sCode;
    @SerializedName("validityInDays")
    @Expose
    private long validityInDays;
    @SerializedName("VideoType")
    @Expose
    private String videoType;
    @SerializedName("isPackage")
    @Expose
    private String isPackage;
    @SerializedName("isActive")
    @Expose
    private String isActive;
    @SerializedName("iPriceWithPackage")
    @Expose
    private String iPriceWithPackage;
    private String ogPrice;
    private List<BundleMovies> videoList;

    @SerializedName("IsShowWithBundle")
    @Expose
    private String IsShowWithBundle;

    public PackageModel(){}

  public PackageModel(long id, String _package, String description, String price, String sCode, long validityInDays, String videoType, String isPackage, String isActive, String iPriceWithPackage, String ogPrice, List<BundleMovies> videoList, String isShowWithBundle, int subscriptionstatus, String mrp, String discount, String upgradeprice) {
    this.id = id;
    this._package = _package;
    this.description = description;
    this.price = price;
    this.sCode = sCode;
    this.validityInDays = validityInDays;
    this.videoType = videoType;
    this.isPackage = isPackage;
    this.isActive = isActive;
    this.iPriceWithPackage = iPriceWithPackage;
    this.ogPrice = ogPrice;
    this.videoList = videoList;
    IsShowWithBundle = isShowWithBundle;
    this.subscriptionstatus = subscriptionstatus;
    this.mrp = mrp;
    this.discount = discount;
    this.upgradeprice = upgradeprice;
  }

  public String getUpgradeprice() {
    return upgradeprice;
  }

  public void setUpgradeprice(String upgradeprice) {
    this.upgradeprice = upgradeprice;
  }

  public String getMrp() {
    return mrp;
  }

  public void setMrp(String mrp) {
    this.mrp = mrp;
  }

  public String getDiscount() {
    return discount;
  }

  public void setDiscount(String discount) {
    this.discount = discount;
  }

  public int getSubscriptionstatus() {
    return subscriptionstatus;
  }

  public void setSubscriptionstatus(int subscriptionstatus) {
    this.subscriptionstatus = subscriptionstatus;
  }

  public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getPackage() {
        return _package;
    }

    public void setPackage(String _package) {
        this._package = _package;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getSCode() {
        return sCode;
    }

    public void setSCode(String sCode) {
        this.sCode = sCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public long getValidityInDays() {
        return validityInDays;
    }

    public void setValidityInDays(long validityInDays) {
        this.validityInDays = validityInDays;
    }

    public String getVideoType() {
        return videoType;
    }

    public void setVideoType(String videoType) {
        this.videoType = videoType;
    }

    public String getIsPackage() {
        return isPackage;
    }

    public void setIsPackage(String isPackage) {
        this.isPackage = isPackage;
    }

    public String getIsActive() {
        return isActive;
    }

    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    public String getiPriceWithPackage() {
        return iPriceWithPackage;
    }

    public void setiPriceWithPackage(String iPriceWithPackage) {
        this.iPriceWithPackage = iPriceWithPackage;
    }

    public void setOgPrice(String ogPrice) {
        this.ogPrice = ogPrice;
    }

    public String getOgPrice() {
        return ogPrice;
    }

    public void setVideoList(List<BundleMovies> videoList) {

        this.videoList = videoList;
    }

    public List<BundleMovies> getVideoList() {
        return videoList;
    }

    public String getIsShowWithBundle() {
        return IsShowWithBundle;
    }

    public void setIsShowWithBundle(String isShowWithBundle) {
        IsShowWithBundle = isShowWithBundle;
    }
}
