package com.idragonpro.andmagnus.activities;

import static com.idragonpro.andmagnus.activities.Subscription.ISDOUBLESUBS;
import static com.idragonpro.andmagnus.activities.Subscription.ISMOVIESBUNDLE;
import static com.idragonpro.andmagnus.activities.Subscription.PACKAGE;
import static com.idragonpro.andmagnus.activities.Subscription.PACKAGE1;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.idragonpro.andmagnus.MyApp;
import com.idragonpro.andmagnus.R;
import com.idragonpro.andmagnus.adapters.SubscriptionAdapter;
import com.idragonpro.andmagnus.api.API;
import com.idragonpro.andmagnus.api.WebApi;
import com.idragonpro.andmagnus.beans.BundleMovies;
import com.idragonpro.andmagnus.beans.Movies;
import com.idragonpro.andmagnus.beans.PackageModel;
import com.idragonpro.andmagnus.helper.SubscriptionOption;
import com.idragonpro.andmagnus.helpers.GlobalModule;
import com.idragonpro.andmagnus.helpers.LocaleHelper;
import com.idragonpro.andmagnus.helpers.SaveSharedPreference;
import com.idragonpro.andmagnus.models.BundlePackage;
import com.idragonpro.andmagnus.models.plan.PackageResp;
import com.idragonpro.andmagnus.models.plan.PackagesResp;
import com.idragonpro.andmagnus.models.plan.PlanData;
import com.idragonpro.andmagnus.responseModels.AnalyticsResponseModel;
import com.idragonpro.andmagnus.responseModels.BundlePackageResponseModel;
import com.idragonpro.andmagnus.responseModels.SplashResponseModel;
import com.idragonpro.andmagnus.utility.UtilityInterface;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NewSubscription extends AppCompatActivity implements UtilityInterface {

  private static final String TAG = NewSubscription.class.getSimpleName();
  Context context;
  BundlePackageResponseModel bundlePackageResponseModel;
  private Dialog dialog= null;
  private FirebaseAnalytics mFirebaseAnalytics;
  RecyclerView recyclerView;
  Button btnSubmit,newPlan;
  private boolean isFABOpen = false;
  public static final String PACKAGE = "package";
  private ImageView imgBack;
  private TextView tvSingleMovie,tvSingleMovieDescription,live_price,actual_price,subscribeplan,subscribedplan;
  private RelativeLayout subscribed;
  private LinearLayout movie;
  public static final String MOVIE = "movie";
  public static final String ISDOUBLESUBS = "isDoubleSubs";
  public static final String ISMOVIESBUNDLE = "isMovieBundle";
  public static final String PACKAGE1 = "package1";

  @Override
  protected void onResume() {
    btnSubmit.setVisibility(View.VISIBLE);
    super.onResume();
  }

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.new_subscription_bottomsheet);

    context = this;
    Log.e("getUsId", SaveSharedPreference.getUserId(context));
    if (getIntent().hasExtra(Info.BUNDLEPACKAGE)) {
      bundlePackageResponseModel = (BundlePackageResponseModel) getIntent().getSerializableExtra(Info.BUNDLEPACKAGE);
    }
    mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
    imgBack = findViewById(R.id.imgBack);
    subscribed = findViewById(R.id.subscribed);
    tvSingleMovie = findViewById(R.id.tvSingleMovie);
    subscribeplan = findViewById(R.id.subscribeplan);
    subscribedplan = findViewById(R.id.subscribedplan);
    movie = findViewById(R.id.movie);
    tvSingleMovieDescription = findViewById(R.id.tvSingleMovieDescription);
    live_price = findViewById(R.id.live_price);
    actual_price = findViewById(R.id.actual_price);
    btnSubmit = findViewById(R.id.btnSubmitPackage);
    newPlan = findViewById(R.id.newPlan);
    imgBack.setOnClickListener(v -> onBackPressed());
    recyclerView = findViewById(R.id.new_subscriber);
    getPlan();

    newPlan.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        Intent intent = new Intent(NewSubscription.this, Register.class);
        startActivity(intent);
        finish();
      }
    });

    btnSubmit.setOnClickListener(v -> {
      if (selectedPackage != null) {// Show progress bar
        btnSubmit.setEnabled(false); // Disable button to prevent multiple clicks
        sendPaymentPageAnalytics(selectedPackage.getPrice()+"",selectedPackage.getId()); // Re-enable button (optional)
      } else {
        Toast.makeText(getApplicationContext(), "Please Select Plan", Toast.LENGTH_LONG).show();
      }
    });
    recordScreenView();
    sendSubscription();
  }
  PackageModel packageModel1 = new PackageModel();
    @Override
    public void finishActivity(Activity activity) {
        if (!activity.isDestroyed()) {
            activity.finish();
        }
    }

    @Override
    public void onBackPressed() {
//        Intent intent = new Intent(context, Info.class);
//        startActivity(intent);
        finish();
    }
  PackageModel selectedPackage = null;
  PackageModel selectedPackage0 = null;
    private void getPlan() {
        WebApi webApi = MyApp.Companion.getInstance().createRetrofitNewInstance();
        Call<PackageResp> call = webApi.getPlan(SaveSharedPreference.getUserId(context)+"" );
        call.enqueue(new Callback<PackageResp>() {
            @Override
            public void onResponse(Call<PackageResp> call, Response<PackageResp> response) {
              PackageResp packageResp = response.body();
              if (packageResp != null && packageResp.getData() != null) {
                PlanData planData = packageResp.getData();
                List<PackageModel> packagelist = new ArrayList<>();
                for(int i=0; i< planData.getPackages().size(); i++) {
                  if(planData.getPackages().get(i).getSubscriptionstatus()==0) {
                    Log.e("status===",planData.getPackages().get(i).getSubscriptionstatus()+"");
                    packagelist.add(planData.getPackages().get(i));
                  } else if(planData.getPackages().get(i).getSubscriptionstatus()==1){
                    tvSingleMovie.setText(planData.getPackages().get(i).getPackage());
                    tvSingleMovieDescription.setText(planData.getPackages().get(i).getDescription());
                    live_price.setText("₹ "+planData.getPackages().get(i).getPrice());
                    actual_price.setText(planData.getPackages().get(i).getMrp());
                    subscribed.setVisibility(View.VISIBLE);
                    newPlan.setVisibility(View.VISIBLE);
                    movie.setVisibility(View.GONE);
                    subscribeplan.setVisibility(View.VISIBLE);
                    String mobileno =  SaveSharedPreference.getMobileNumber(
                      getApplicationContext()
                    );
                    subscribedplan.setText("Current Plan/आपका प्लान ("+mobileno+") ");
                    subscribedplan.setVisibility(View.VISIBLE);
                    btnSubmit.setText("Upgrade Plan");
                  }
                }
                packagelist.add(new PackageModel(0, "", "Single Movie Plan\nसिंगल मूवी खरीदने के लिए होम पेज पर किसी भी मूवी के पोस्टर पर क्लिक करें और आगे भुगतान करें", "", "", 0, "", "", "0", "", "", null, "",0,"","",""));
                packagelist.add(new PackageModel(0, "", "Single Web Series plan\nसिंगल Web Series खरीदने के लिए होम पेज पर किसी भी Web Series के पोस्टर पर क्लिक करें और आगे भुगतान करें\nClick on any Web Series", "", "", 0, "", "", "0", "", "", null, "",0,"","",""));
                packagelist.add(new PackageModel(0, "", "Customer Care No - 9321199867\nEmail I'd - idragonglobal@gmail.com", "", "", 0, "", "", "0", "", "", null, "",0,"","",""));
                SubscriptionAdapter adapter = new SubscriptionAdapter(packagelist, item -> {
                  if (item.getUpgradeprice() != null && !item.getUpgradeprice().isEmpty() && !item.getUpgradeprice().equals("0")) {
                    item.setPrice(item.getUpgradeprice());
                  } else {
                    item.setPrice(item.getPrice());
                  }
                  selectedPackage = item;
                });// Ensure this matches your layout ID
                recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                recyclerView.setAdapter(adapter);
              } else {
                Log.e("SubscriptionActivity", "Error: PackageResp or PlanData is null");
              }
            }
            @Override
            public void onFailure(Call<PackageResp> call, Throwable t) {
              t.printStackTrace();
              Log.e("errorgetallpackagesresponse==",t.toString());
            }
        });
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.onAttach(base, "en"));
    }
  private void recordScreenView() {
    mFirebaseAnalytics.setCurrentScreen(this, null, null);// [END set_current_screen]
  }

  private void sendPaymentPageAnalytics(String price, long id) {
    WebApi webApi = MyApp.Companion.getInstance().createRetrofitNewInstance();
    Call<AnalyticsResponseModel> call = webApi.sendpaymentpageAnalytics(SaveSharedPreference.getUserId(context),
      "",
      id,
      price);
    call.enqueue(new Callback<AnalyticsResponseModel>() {
      @Override
      public void onResponse(Call<AnalyticsResponseModel> call, Response<AnalyticsResponseModel> response) {
        Intent intent = new Intent(NewSubscription.this, PaymentActivity.class);
        intent.putExtra(PACKAGE, selectedPackage);
        intent.putExtra(ISDOUBLESUBS, false);
        intent.putExtra(ISMOVIESBUNDLE, false);
        intent.putExtra(PACKAGE1, packageModel1);
        startActivity(intent);
//        Toast.makeText(getApplicationContext(), "Please wait..", Toast.LENGTH_LONG).show();// Hide progress bar (optional, depends on PaymentActivity)
        btnSubmit.setEnabled(true);
      }
      @Override
      public void onFailure(Call<AnalyticsResponseModel> call, Throwable t) {
        t.printStackTrace();
      }
    });
  }

  private void sendSubscription() {
    WebApi webApi = MyApp.Companion.getInstance().createRetrofitNewInstance();
    Call<AnalyticsResponseModel> call = webApi.sendsubscriptionAnalyticss(SaveSharedPreference.getUserId(getApplicationContext()),
      "attempt to vip subscription");
    call.enqueue(new Callback<AnalyticsResponseModel>() {
      @Override
      public void onResponse(Call<AnalyticsResponseModel> call, Response<AnalyticsResponseModel> response) {

      }

      @Override
      public void onFailure(Call<AnalyticsResponseModel> call, Throwable t) {
        t.printStackTrace();
      }
    });
  }

}


