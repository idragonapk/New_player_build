package com.idragonpro.andmagnus.radapters;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.ads.nativetemplates.NativeTemplateStyle;
import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.admanager.AdManagerAdRequest;
import com.idragonpro.andmagnus.R;
import com.idragonpro.andmagnus.activities.Info;
import com.idragonpro.andmagnus.activities.ViewAllVideos;
import com.idragonpro.andmagnus.beans.Movies;
import com.idragonpro.andmagnus.models.Banners;

import java.util.List;

public class ViewAllRvAdapter extends RecyclerView.Adapter<ViewAllRvAdapter.ViewHolder> {

    private static final String TAG = ViewAllRvAdapter.class.getSimpleName();
    private final ViewAllVideos viewAllVideos;
    private final List<Banners> moviesList;

    public ViewAllRvAdapter(ViewAllVideos viewAllVideos, List<Banners> moviesList) {
        this.viewAllVideos = viewAllVideos;
        this.moviesList = moviesList;
    }

    @NonNull
    @Override
    public ViewAllRvAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.movie_list_item, parent, false);
        ViewAllRvAdapter.ViewHolder viewHolder = new ViewAllRvAdapter.ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewAllRvAdapter.ViewHolder holder, int position) {
        Banners movie = moviesList.get(position);
        Movies movies = movie.getVideodetails();
        if (movies.getsSmallBanner() != null && !movies.getsSmallBanner()
            .equalsIgnoreCase("null") && !movies.getsSmallBanner().isEmpty()) {
            Glide.with(holder.imgMovieBanner.getContext())
                .load(movies.getsSmallBanner())
                .centerCrop()
                .into(holder.imgMovieBanner);
        } else {
            Glide.with(holder.imgMovieBanner.getContext()).load(R.drawable.not_img)
                .centerCrop()
                .into(holder.imgMovieBanner);
        }

        holder.tvGenre.setText(movies.getsGenre());
        Log.d(TAG, "onBindViewHolder: " + movies.getsName());
        holder.tvName.setText(movies.getsName());
        holder.tvYear.setText(movies.getsYear());
        holder.llMoviesList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(viewAllVideos, Info.class);
                intent.putExtra("movie", movies);
                viewAllVideos.startActivity(intent);
               /* boolean isContentAvailable = false;
                for (int i=0;i<listOfStringfromString.size();i++) {
                    if (GlobalModule.sCountry.equalsIgnoreCase(listOfStringfromString.get(i)) || listOfStringfromString.get(i).equalsIgnoreCase("Worldwide")) {
                        isContentAvailable = true;
                        Intent intent = new Intent(viewAllVideos, Info.class);
                        intent.putExtra("movie", movie);
                        viewAllVideos.startActivity(intent);
                    }
                }
                if(!isContentAvailable){
                    final AlertDialog adExp = new AlertDialog.Builder(viewAllVideos).create();
                    String msg = "Sorry "+movie.getsName()+" is currently not available in your region";
                    adExp.setMessage(msg);
                    adExp.setCancelable(true);
                    adExp.setCanceledOnTouchOutside(true);
                    adExp.setButton(DialogInterface.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            adExp.dismiss();
                        }
                    });
                    adExp.show();

                }*/
            }
        });

        if (position == 1 || position == 6 || position == 11) {
            holder.frNative.setVisibility(View.VISIBLE);
            loadNativeAd(holder.frNative, holder.itemView.getContext());
        } else {
            holder.frNative.setVisibility(View.GONE);
        }
    }

    private void loadNativeAd(FrameLayout frNative, Context context) {
        AdLoader adLoader = new AdLoader.Builder(
                context, context.getString(R.string.native_small_ad_unit_id)).forNativeAd(nativeAd -> {
                    NativeTemplateStyle styles = new NativeTemplateStyle.Builder().build();
                    LayoutInflater inflater = LayoutInflater.from(context);
                    LinearLayout adviewTop = (LinearLayout) inflater.inflate(R.layout.ad_unified_small, null);
                    TemplateView template = adviewTop.findViewById(R.id.my_template);
                    template.setStyles(styles);
                    template.setNativeAd(nativeAd);
                    if (frNative != null) {
                        frNative.removeAllViews();
                        frNative.addView(adviewTop);
                    }
                }).build();

        adLoader.loadAd(new AdManagerAdRequest.Builder().build());
    }

    @Override
    public int getItemCount() {
        return moviesList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private final ImageView imgMovieBanner;
        private final TextView tvName, tvGenre, tvYear;
        private final RelativeLayout llMoviesList;
        private final FrameLayout frNative;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgMovieBanner = (ImageView) itemView.findViewById(R.id.imgMovieIcon);
            tvName = (TextView) itemView.findViewById(R.id.tvName);
            tvGenre = (TextView) itemView.findViewById(R.id.tvGenre);
            tvYear = (TextView) itemView.findViewById(R.id.tvYear);
            llMoviesList = (RelativeLayout) itemView.findViewById(R.id.llMoviesList);
            frNative = (FrameLayout) itemView.findViewById(R.id.frNative);
        }
    }
}
