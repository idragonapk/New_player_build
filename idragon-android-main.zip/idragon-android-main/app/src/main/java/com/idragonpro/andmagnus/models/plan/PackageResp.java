package com.idragonpro.andmagnus.models.plan;

import com.google.gson.annotations.SerializedName;

public class PackageResp {
  @SerializedName("data")
  PlanData data;

  @SerializedName("status")
  String status;


  public void setData(PlanData data) {
    this.data = data;
  }

  public PlanData getData() {
    return data;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getStatus() {
    return status;
  }
}
