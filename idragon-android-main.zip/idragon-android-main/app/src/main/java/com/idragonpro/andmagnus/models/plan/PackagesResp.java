package com.idragonpro.andmagnus.models.plan;

import com.google.gson.annotations.SerializedName;

public class PackagesResp {
  @SerializedName("id")
  int id;
  private boolean isSelected;
  @SerializedName("Package")
  String Package;

  @SerializedName("Description")
  String Description;

  public boolean isSelected() {
    return isSelected;
  }

  public void setSelected(boolean selected) {
    isSelected = selected;
  }

  @SerializedName("Price")
  String Price;

  @SerializedName("IosPrice")
  String IosPrice;

  @SerializedName("sCode")
  String sCode;

  @SerializedName("validityInDays")
  int validityInDays;

  @SerializedName("IosvalidityInDays")
  int IosvalidityInDays;

  @SerializedName("VideoType")
  String VideoType;

  @SerializedName("isPackage")
  String isPackage;

  @SerializedName("isMain")
  int isMain;

  @SerializedName("isActive")
  String isActive;

  @SerializedName("IsShowWithBundle")
  String IsShowWithBundle;

  @SerializedName("priority")
  int priority;

  @SerializedName("hindiPackage")
  String hindiPackage;

  @SerializedName("hindiPackageDescription")
  String hindiPackageDescription;

  @SerializedName("marathiPackage")
  String marathiPackage;

  @SerializedName("marathiPackageDescription")
  String marathiPackageDescription;

  @SerializedName("tamilPackage")
  String tamilPackage;

  @SerializedName("tamilPackageDescription")
  String tamilPackageDescription;

  @SerializedName("telguPackage")
  String telguPackage;

  @SerializedName("telguPackageDescription")
  String telguPackageDescription;

  @SerializedName("kannadaPackage")
  String kannadaPackage;

  @SerializedName("kannadaPackageDescription")
  String kannadaPackageDescription;

  @SerializedName("punjabiPackage")
  String punjabiPackage;

  @SerializedName("punjabiPackageDescription")
  String punjabiPackageDescription;

  @SerializedName("gujaratiPackage")
  String gujaratiPackage;

  @SerializedName("gujaratiPackageDescription")
  String gujaratiPackageDescription;

  @SerializedName("bengaliPackage")
  String bengaliPackage;

  @SerializedName("bengaliPackageDescription")
  String bengaliPackageDescription;

  @SerializedName("urduPackage")
  String urduPackage;

  @SerializedName("urduPackageDescription")
  String urduPackageDescription;

  @SerializedName("StatusId")
  String StatusId;

  @SerializedName("StatusName")
  String StatusName;

  @SerializedName("CreatedById")
  String CreatedById;

  @SerializedName("ModifiedById")
  String ModifiedById;

  @SerializedName("created_at")
  String createdAt;

  @SerializedName("updated_at")
  String updatedAt;

  @SerializedName("deleted_at")
  String deletedAt;

  @SerializedName("subscription_status")
  int subscriptionStatus;


  public void setId(int id) {
    this.id = id;
  }
  public int getId() {
    return id;
  }

  public void setPackage(String Package) {
    this.Package = Package;
  }
  public String getPackage() {
    return Package;
  }

  public void setDescription(String Description) {
    this.Description = Description;
  }
  public String getDescription() {
    return Description;
  }

  public void setPrice(String Price) {
    this.Price = Price;
  }
  public String getPrice() {
    return Price;
  }

  public void setIosPrice(String IosPrice) {
    this.IosPrice = IosPrice;
  }
  public String getIosPrice() {
    return IosPrice;
  }

  public void setSCode(String sCode) {
    this.sCode = sCode;
  }
  public String getSCode() {
    return sCode;
  }

  public void setValidityInDays(int validityInDays) {
    this.validityInDays = validityInDays;
  }
  public int getValidityInDays() {
    return validityInDays;
  }

  public void setIosvalidityInDays(int IosvalidityInDays) {
    this.IosvalidityInDays = IosvalidityInDays;
  }
  public int getIosvalidityInDays() {
    return IosvalidityInDays;
  }

  public void setVideoType(String VideoType) {
    this.VideoType = VideoType;
  }
  public String getVideoType() {
    return VideoType;
  }

  public void setIsPackage(String isPackage) {
    this.isPackage = isPackage;
  }
  public String getIsPackage() {
    return isPackage;
  }

  public void setIsMain(int isMain) {
    this.isMain = isMain;
  }
  public int getIsMain() {
    return isMain;
  }

  public void setIsActive(String isActive) {
    this.isActive = isActive;
  }
  public String getIsActive() {
    return isActive;
  }

  public void setIsShowWithBundle(String IsShowWithBundle) {
    this.IsShowWithBundle = IsShowWithBundle;
  }
  public String getIsShowWithBundle() {
    return IsShowWithBundle;
  }

  public void setPriority(int priority) {
    this.priority = priority;
  }
  public int getPriority() {
    return priority;
  }

  public void setHindiPackage(String hindiPackage) {
    this.hindiPackage = hindiPackage;
  }
  public String getHindiPackage() {
    return hindiPackage;
  }

  public void setHindiPackageDescription(String hindiPackageDescription) {
    this.hindiPackageDescription = hindiPackageDescription;
  }
  public String getHindiPackageDescription() {
    return hindiPackageDescription;
  }

  public void setMarathiPackage(String marathiPackage) {
    this.marathiPackage = marathiPackage;
  }
  public String getMarathiPackage() {
    return marathiPackage;
  }

  public void setMarathiPackageDescription(String marathiPackageDescription) {
    this.marathiPackageDescription = marathiPackageDescription;
  }
  public String getMarathiPackageDescription() {
    return marathiPackageDescription;
  }

  public void setTamilPackage(String tamilPackage) {
    this.tamilPackage = tamilPackage;
  }
  public String getTamilPackage() {
    return tamilPackage;
  }

  public void setTamilPackageDescription(String tamilPackageDescription) {
    this.tamilPackageDescription = tamilPackageDescription;
  }
  public String getTamilPackageDescription() {
    return tamilPackageDescription;
  }

  public void setTelguPackage(String telguPackage) {
    this.telguPackage = telguPackage;
  }
  public String getTelguPackage() {
    return telguPackage;
  }

  public void setTelguPackageDescription(String telguPackageDescription) {
    this.telguPackageDescription = telguPackageDescription;
  }
  public String getTelguPackageDescription() {
    return telguPackageDescription;
  }

  public void setKannadaPackage(String kannadaPackage) {
    this.kannadaPackage = kannadaPackage;
  }
  public String getKannadaPackage() {
    return kannadaPackage;
  }

  public void setKannadaPackageDescription(String kannadaPackageDescription) {
    this.kannadaPackageDescription = kannadaPackageDescription;
  }
  public String getKannadaPackageDescription() {
    return kannadaPackageDescription;
  }

  public void setPunjabiPackage(String punjabiPackage) {
    this.punjabiPackage = punjabiPackage;
  }
  public String getPunjabiPackage() {
    return punjabiPackage;
  }

  public void setPunjabiPackageDescription(String punjabiPackageDescription) {
    this.punjabiPackageDescription = punjabiPackageDescription;
  }
  public String getPunjabiPackageDescription() {
    return punjabiPackageDescription;
  }

  public void setGujaratiPackage(String gujaratiPackage) {
    this.gujaratiPackage = gujaratiPackage;
  }
  public String getGujaratiPackage() {
    return gujaratiPackage;
  }

  public void setGujaratiPackageDescription(String gujaratiPackageDescription) {
    this.gujaratiPackageDescription = gujaratiPackageDescription;
  }
  public String getGujaratiPackageDescription() {
    return gujaratiPackageDescription;
  }

  public void setBengaliPackage(String bengaliPackage) {
    this.bengaliPackage = bengaliPackage;
  }
  public String getBengaliPackage() {
    return bengaliPackage;
  }

  public void setBengaliPackageDescription(String bengaliPackageDescription) {
    this.bengaliPackageDescription = bengaliPackageDescription;
  }
  public String getBengaliPackageDescription() {
    return bengaliPackageDescription;
  }

  public void setUrduPackage(String urduPackage) {
    this.urduPackage = urduPackage;
  }
  public String getUrduPackage() {
    return urduPackage;
  }

  public void setUrduPackageDescription(String urduPackageDescription) {
    this.urduPackageDescription = urduPackageDescription;
  }
  public String getUrduPackageDescription() {
    return urduPackageDescription;
  }

  public void setStatusId(String StatusId) {
    this.StatusId = StatusId;
  }
  public String getStatusId() {
    return StatusId;
  }

  public void setStatusName(String StatusName) {
    this.StatusName = StatusName;
  }
  public String getStatusName() {
    return StatusName;
  }

  public void setCreatedById(String CreatedById) {
    this.CreatedById = CreatedById;
  }
  public String getCreatedById() {
    return CreatedById;
  }

  public void setModifiedById(String ModifiedById) {
    this.ModifiedById = ModifiedById;
  }
  public String getModifiedById() {
    return ModifiedById;
  }

  public void setCreatedAt(String createdAt) {
    this.createdAt = createdAt;
  }
  public String getCreatedAt() {
    return createdAt;
  }

  public void setUpdatedAt(String updatedAt) {
    this.updatedAt = updatedAt;
  }
  public String getUpdatedAt() {
    return updatedAt;
  }

  public void setDeletedAt(String deletedAt) {
    this.deletedAt = deletedAt;
  }
  public String getDeletedAt() {
    return deletedAt;
  }

  public void setSubscriptionStatus(int subscriptionStatus) {
    this.subscriptionStatus = subscriptionStatus;
  }
  public int getSubscriptionStatus() {
    return subscriptionStatus;
  }

}
