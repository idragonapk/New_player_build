package com.idragonpro.andmagnus.models.plan;

import com.google.gson.annotations.SerializedName;

public class PaymentGatewaysResp {
  @SerializedName("id")
  int id;

  @SerializedName("PgName")
  String PgName;

  @SerializedName("Merchant_Id")
  String MerchantId;

  @SerializedName("Client_Id")
  String ClientId;

  @SerializedName("Client_Secret_Key")
  String ClientSecretKey;

  @SerializedName("Api_Key")
  String ApiKey;

  @SerializedName("Api_Auth_Token")
  String ApiAuthToken;

  @SerializedName("Api_Secret_Key")
  String ApiSecretKey;

  @SerializedName("Optional_1")
  String Optional1;

  @SerializedName("Optional_2")
  String Optional2;

  @SerializedName("Optional_3")
  String Optional3;

  @SerializedName("isActive")
  int isActive;

  @SerializedName("created_at")
  String createdAt;

  @SerializedName("updated_at")
  String updatedAt;


  public void setId(int id) {
    this.id = id;
  }
  public int getId() {
    return id;
  }

  public void setPgName(String PgName) {
    this.PgName = PgName;
  }
  public String getPgName() {
    return PgName;
  }

  public void setMerchantId(String MerchantId) {
    this.MerchantId = MerchantId;
  }
  public String getMerchantId() {
    return MerchantId;
  }

  public void setClientId(String ClientId) {
    this.ClientId = ClientId;
  }
  public String getClientId() {
    return ClientId;
  }

  public void setClientSecretKey(String ClientSecretKey) {
    this.ClientSecretKey = ClientSecretKey;
  }
  public String getClientSecretKey() {
    return ClientSecretKey;
  }

  public void setApiKey(String ApiKey) {
    this.ApiKey = ApiKey;
  }
  public String getApiKey() {
    return ApiKey;
  }

  public void setApiAuthToken(String ApiAuthToken) {
    this.ApiAuthToken = ApiAuthToken;
  }
  public String getApiAuthToken() {
    return ApiAuthToken;
  }

  public void setApiSecretKey(String ApiSecretKey) {
    this.ApiSecretKey = ApiSecretKey;
  }
  public String getApiSecretKey() {
    return ApiSecretKey;
  }

  public void setOptional1(String Optional1) {
    this.Optional1 = Optional1;
  }
  public String getOptional1() {
    return Optional1;
  }

  public void setOptional2(String Optional2) {
    this.Optional2 = Optional2;
  }
  public String getOptional2() {
    return Optional2;
  }

  public void setOptional3(String Optional3) {
    this.Optional3 = Optional3;
  }
  public String getOptional3() {
    return Optional3;
  }

  public void setIsActive(int isActive) {
    this.isActive = isActive;
  }
  public int getIsActive() {
    return isActive;
  }

  public void setCreatedAt(String createdAt) {
    this.createdAt = createdAt;
  }
  public String getCreatedAt() {
    return createdAt;
  }

  public void setUpdatedAt(String updatedAt) {
    this.updatedAt = updatedAt;
  }
  public String getUpdatedAt() {
    return updatedAt;
  }

}
