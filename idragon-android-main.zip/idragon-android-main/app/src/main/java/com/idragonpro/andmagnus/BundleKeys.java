package com.idragonpro.andmagnus;

public class BundleKeys {

    public static String TAB_NAME = "tabName";
}
