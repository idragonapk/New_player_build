package com.idragonpro.andmagnus.utility;

public class ServiceUtility{

  public static Object chkNull(Object pData){
    return (pData==null?"":pData);
  }
}