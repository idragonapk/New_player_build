package com.idragonpro.andmagnus.helpers

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import android.util.Log
import com.idragonpro.andmagnus.work.DownloadWorker.Companion.TAG

class DownloadCompleteReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context?, intent: Intent?) {
    if (intent?.action == DownloadManager.ACTION_DOWNLOAD_COMPLETE) {
      val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
      if (id != -1L) {
        val downloadManager = context?.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val query = DownloadManager.Query().setFilterById(id)
        val cursor = downloadManager.query(query)
        if (cursor.moveToFirst()) {
          val statusColumnIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)
          val status = cursor.getInt(statusColumnIndex)
          val uriColumnIndex = cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI)
          val localUri = cursor.getString(uriColumnIndex)

          when (status) {
            DownloadManager.STATUS_SUCCESSFUL -> {
              Toast.makeText(context, "Download Complete!", Toast.LENGTH_LONG).show()
              Log.d(TAG, "Download successful: $localUri")
              // You can now do something with the downloaded file,
              // e.g., notify the user, add to a gallery, etc.
            }
            DownloadManager.STATUS_FAILED -> {
              val reasonColumnIndex = cursor.getColumnIndex(DownloadManager.COLUMN_REASON)
              val reason = cursor.getInt(reasonColumnIndex)
              Toast.makeText(context, "Download Failed: $reason", Toast.LENGTH_LONG).show()
              Log.e(TAG, "Download failed with reason: $reason")
            }
          }
        }
        cursor.close()
      }
    }
  }
}
