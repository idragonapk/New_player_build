package com.idragonpro.andmagnus.radapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.admanager.AdManagerAdRequest;
import com.google.android.gms.ads.admanager.AdManagerAdView;
import com.idragonpro.andmagnus.R;
import com.idragonpro.andmagnus.activities.ViewAllVideos;
import com.idragonpro.andmagnus.fragments.NewHomeFragment;
import com.idragonpro.andmagnus.models.Banners;
import com.idragonpro.andmagnus.models.Sections;

import java.io.Serializable;
import java.util.List;

public class

HomeRecyclerViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final String TAG = HomeRecyclerViewAdapter.class.getSimpleName();
    private static final int AD_TYPE = 0;
    private static final int CONTENT_TYPE = 1;
    private final NewHomeFragment newHomeFragment;
    private List<Sections> homeContent;
    private final String tabName;
    public String selectedString = "";
    public boolean isPlaying = false;
    public SimpleExoPlayer exoplayer;
    public MutableLiveData<SimpleExoPlayer> liveDataPlayer = new MutableLiveData<>();

    public HomeRecyclerViewAdapter(NewHomeFragment newHomeFragment, List<Sections> homeContent, String tabName) {
        this.newHomeFragment = newHomeFragment;
        this.homeContent = homeContent;
        this.tabName = tabName;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_main_item, parent, false);
        HomeRecyclerViewAdapter.ViewHolder viewHolder = new HomeRecyclerViewAdapter.ViewHolder(view);
        return viewHolder;
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        List<Banners> contents = homeContent.get(position).getBanners();
        ((ViewHolder) holder).tvTitle.setText(homeContent.get(position).getCategory());
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(newHomeFragment.getActivity(),
                LinearLayoutManager.HORIZONTAL,
                false);
        ((ViewHolder) holder).rvHome.setLayoutManager(linearLayoutManager);
        //scroll
        int visiblePos = linearLayoutManager.findFirstVisibleItemPosition();
        Log.d("TAG", "check the mute pos2:" + visiblePos);
        //
        HomeRowRecyclerViewAdapter homeRowRecyclerViewAdapter = new HomeRowRecyclerViewAdapter(newHomeFragment,
                contents,
                tabName,
                homeContent.get(position).getiType());
        exoplayer = homeRowRecyclerViewAdapter.simpleExoPlayer;
        homeRowRecyclerViewAdapter.liveDataPlayer.observeForever(simpleExoPlayer -> liveDataPlayer.setValue(
                simpleExoPlayer));
        ((ViewHolder) holder).rvHome.setAdapter(homeRowRecyclerViewAdapter);

        ((ViewHolder) holder).rvHome.setOnTouchListener((view, motionEvent) -> {
            if (motionEvent.getAction() == MotionEvent.ACTION_MOVE) {
                newHomeFragment.disableRefresh();
            } else {
                newHomeFragment.enableRefresh();
            }
            return false;
        });
        ((ViewHolder) holder).imgArrow.setOnClickListener(v -> {
            Intent intent = new Intent(newHomeFragment.getActivity(), ViewAllVideos.class);
            intent.putExtra("movies", (Serializable) contents);
            intent.putExtra("title", homeContent.get(position).getCategory());
            newHomeFragment.getActivity().startActivity(intent);
        });
        if (position == 1 || position == 4 || position == 7 || position ==10 || position == 13 || position == 16 || position == 19 || position == 22 || position == 25  || position == 28 || position == 31 || position == 34 || position == 37  || position == 40 || position == 43 ) {
            ((ViewHolder) holder).bannerAdView.setVisibility(View.VISIBLE);
            bannerAdsShow(((ViewHolder) holder).bannerAdView, holder.itemView.getContext());
        } else {
            ((ViewHolder) holder).bannerAdView.setVisibility(View.GONE);
        }
    }

    private void bannerAdsShow(FrameLayout bannerAdView, Context context) {
        AdManagerAdView adView = new AdManagerAdView(newHomeFragment.getActivity());
        adView.setAdSizes(AdSize.LARGE_BANNER);
        adView.setAdUnitId(context.getString(R.string.banner_320x100_ad_unit_id));
        bannerAdView.removeAllViews();
        bannerAdView.addView(adView);

        AdManagerAdRequest adRequest = new AdManagerAdRequest.Builder().build();
        adView.loadAd(adRequest);
    }

    @Override
    public int getItemCount() {
        return homeContent.size();
    }

    public void setHomeContent(List<Sections> homeContent) {
        this.homeContent = homeContent;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private final TextView tvTitle;
        private final RecyclerView rvHome;
        private final FrameLayout bannerAdView;
        private final ImageView imgArrow;
        private final LinearLayout homeMain;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            rvHome = itemView.findViewById(R.id.rvHome);
            bannerAdView = itemView.findViewById(R.id.bannerAdView);
            imgArrow = itemView.findViewById(R.id.imgArrow);
            homeMain = itemView.findViewById(R.id.homeMain);
        }
    }

    private class AdViewHolder extends RecyclerView.ViewHolder {

        private final FrameLayout bannerAdView;
        private final LinearLayout homeMain;

        public AdViewHolder(@NonNull View itemView) {
            super(itemView);
            bannerAdView = itemView.findViewById(R.id.bannerAdView);
            homeMain = itemView.findViewById(R.id.homeMain);
        }
    }

    @Override
    public int getItemViewType(int position) {
        /*if (position == 0) {
            return AD_TYPE;
        }*/
        return CONTENT_TYPE;
    }

    /*@Override
    public void onAttachedToRecyclerView(@NonNull RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        recyclerView.computeVerticalScrollOffset();
        RecyclerView.LayoutManager manager = recyclerView.getLayoutManager();
        Log.d("TAG","check the mute posattach11:"+manager);
        if(manager instanceof LinearLayoutManager && getItemCount() > 0) {
            LinearLayoutManager llm = (LinearLayoutManager) manager;
            recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
                @Override
                public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                    super.onScrollStateChanged(recyclerView, newState);
                    int visiblePosition = llm.findFirstCompletelyVisibleItemPosition();
                    if (visiblePosition > -1) {
                        View v = llm.findViewByPosition(visiblePosition);


                        Log.d("TAG", "check the mute posattach1:" + visiblePosition);
                    }
                }

                @Override
                public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                    super.onScrolled(recyclerView, dx, dy);
                    int visiblePosition = llm.findFirstCompletelyVisibleItemPosition();
                    if(visiblePosition > -1) {
                        View v = llm.findViewByPosition(visiblePosition);
                        Log.d("TAG","check the mute posattach2:"+visiblePosition);
                        //do something
                    }
                }
            });
        }
    }*/

    @Override
    public void onDetachedFromRecyclerView(@NonNull RecyclerView recyclerView) {
        super.onDetachedFromRecyclerView(recyclerView);

    }
}
