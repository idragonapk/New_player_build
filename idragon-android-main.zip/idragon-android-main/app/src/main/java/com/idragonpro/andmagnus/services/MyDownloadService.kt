package com.idragonpro.andmagnus.services

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log

class MyDownloadService : Service() {

  private val TAG = "MyDownloadService"

  override fun onCreate() {
    super.onCreate()
    Log.d(TAG, "MyDownloadService created")
    // Initialize things needed for your download
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    Log.d(TAG, "MyDownloadService started with command")
    // This is where you would start your download logic.
    // You can get data from the 'intent' if passed (e.g., download URL).

    // If you plan to make it a foreground service later,
    // you'll call startForeground() here with a notification.

    // Indicate how the system should handle the service if it's killed
    return START_STICKY // or START_NOT_STICKY, START_REDELIVER_INTENT
  }

  override fun onBind(intent: Intent?): IBinder? {
    // Return null if you don't provide binding for other components
    // Otherwise, return an IBinder implementation
    Log.d(TAG, "MyDownloadService bound")
    return null
  }

  override fun onDestroy() {
    super.onDestroy()
    Log.d(TAG, "MyDownloadService destroyed")
    // Clean up any resources (stop download, release network connections, etc.)
  }
}
