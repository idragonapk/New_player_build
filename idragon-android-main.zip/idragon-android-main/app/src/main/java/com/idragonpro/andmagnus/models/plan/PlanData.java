package com.idragonpro.andmagnus.models.plan;

import com.google.gson.annotations.SerializedName;
import com.idragonpro.andmagnus.beans.PackageModel;

import java.util.List;

public class PlanData {
  @SerializedName("packages")
  List<PackageModel> packages;

  @SerializedName("payment_gateways")
  List<PaymentGatewaysResp> paymentGateways;


  public void setPackages(List<PackageModel> packages) {
    this.packages = packages;
  }
  public List<PackageModel> getPackages() {
    return packages;
  }

  public void setPaymentGateways(List<PaymentGatewaysResp> paymentGateways) {
    this.paymentGateways = paymentGateways;
  }
  public List<PaymentGatewaysResp> getPaymentGateways() {
    return paymentGateways;
  }

}
