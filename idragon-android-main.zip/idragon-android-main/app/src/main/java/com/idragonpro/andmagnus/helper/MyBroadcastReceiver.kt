package com.idragonpro.andmagnus.helper

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class MyBroadcastReceiver : BroadcastReceiver() {

  private val TAG = "MyBroadcastReceiver"

  // This method is called when a broadcast is received.
  override fun onReceive(context: Context?, intent: Intent?) {
    intent?.let {
      Log.d(TAG, "Broadcast received: ${it.action}")

      when (it.action) {
        // Example: Handle a custom action
        "com.idragonpro.andmagnus.ACTION_DOWNLOAD_COMPLETE" -> {
          val downloadId = it.getLongExtra("download_id", -1L)
          Log.d(TAG, "Download complete for ID: $downloadId")
          // Perform actions like showing a notification, updating UI, etc.
        }
        // Example: Handle system broadcasts
        Intent.ACTION_BOOT_COMPLETED -> {
          Log.d(TAG, "Device booted up.")
          // E.g., if you need to reschedule alarms or services after a reboot
        }
        // Add more actions as needed
        else -> {}
      }
    }
  }
}
