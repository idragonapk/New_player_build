package com.idragonpro.andmagnus.helper;

public class SubscriptionOption {
  private String title;
  private String price;
  private String offerprice;
  private String description;
  private boolean isSelected;

  public SubscriptionOption(String title,String price, String offerprice, String description, boolean isSelected) {
    this.title = title;
    this.price = price;
    this.offerprice = offerprice;
    this.description = description;
    this.isSelected = isSelected;
  }

  public String getPrice() {
    return price;
  }

  public void setPrice(String price) {
    this.price = price;
  }

  public String getOfferprice() {
    return offerprice;
  }

  public void setOfferprice(String offerprice) {
    this.offerprice = offerprice;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public boolean isSelected() {
    return isSelected;
  }

  public void setSelected(boolean selected) {
    isSelected = selected;
  }
}
