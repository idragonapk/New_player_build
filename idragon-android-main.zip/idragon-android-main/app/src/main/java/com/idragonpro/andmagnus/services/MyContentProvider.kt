package com.idragonpro.andmagnus.services

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.net.Uri
import android.util.Log

class MyContentProvider : ContentProvider() {

  private val TAG = "MyContentProvider"

  // Called when the provider is created.
  override fun onCreate(): Boolean {
    Log.d(TAG, "MyContentProvider created")
    // Return true if the provider was successfully loaded
    return true
  }

  // Implement this to handle query requests from clients.
  override fun query(
    uri: Uri,
    projection: Array<out String>?,
    selection: String?,
    selectionArgs: Array<out String>?,
    sortOrder: String?
  ): Cursor? {
    Log.d(TAG, "Query received for URI: $uri")
    // Implement your query logic here (e.g., querying a database)
    return null
  }

  // Implement this to handle requests for the MIME type of the data at the given URI.
  override fun getType(uri: Uri): String? {
    Log.d(TAG, "getType received for URI: $uri")
    // Return the MIME type of the data at the given URI
    return null
  }

  // Implement this to handle insert requests from clients.
  override fun insert(uri: Uri, values: ContentValues?): Uri? {
    Log.d(TAG, "Insert received for URI: $uri")
    // Implement your insert logic here (e.g., inserting into a database)
    return null
  }

  // Implement this to handle delete requests from clients.
  override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int {
    Log.d(TAG, "Delete received for URI: $uri")
    // Implement your delete logic here
    return 0
  }

  // Implement this to handle update requests from clients.
  override fun update(
    uri: Uri,
    values: ContentValues?,
    selection: String?,
    selectionArgs: Array<out String>?
  ): Int {
    Log.d(TAG, "Update received for URI: $uri")
    // Implement your update logic here
    return 0
  }
}
