package com.idragonpro.andmagnus.adapters;

import android.graphics.Paint;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.idragonpro.andmagnus.R;
import com.idragonpro.andmagnus.beans.PackageModel;
import com.idragonpro.andmagnus.models.plan.PackagesResp;

import java.util.List;

public class SubscriptionAdapter extends RecyclerView.Adapter<SubscriptionAdapter.SubscriptionViewHolder> {
  private List<PackageModel> options;
  private int selectedPosition = -1;
  private OnItemClickListener listener;
  public SubscriptionAdapter(List<PackageModel> options, OnItemClickListener listener) {
    this.options = options;
    this.listener = listener;
  }

  public interface OnItemClickListener {
    void onItemClick(PackageModel item);
  }

  @Override
  public SubscriptionViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.subscription_item_new, parent, false);
    return new SubscriptionViewHolder(view);
  }

  @Override
  public void onBindViewHolder(SubscriptionViewHolder holder, int position) {
    PackageModel option = options.get(position);

    // Bind data to views
    holder.bind(option, listener);

    // Bind title
    if (option.getPackage() != null && !option.getPackage().isEmpty()) {
      holder.title.setVisibility(View.VISIBLE);
      holder.title.setText(option.getPackage());
    } else {
      holder.title.setVisibility(View.GONE);
    }

    // Bind price
    if (option.getPrice() != null && !option.getPrice().isEmpty()) {
      holder.price.setVisibility(View.VISIBLE);
      holder.price.setText("₹ "+option.getPrice());
    } else {
      holder.price.setVisibility(View.GONE);
    }
    if (option.getMrp() != null && !option.getMrp().isEmpty()) {
      holder.offerprice.setVisibility(View.VISIBLE);
      holder.offerprice.setText("₹ "+option.getMrp());

    } else {
      holder.offerprice.setVisibility(View.GONE);
    }

    // Bind description
    if (option.getDescription() != null) {
      holder.description.setText(option.getDescription());
    } else {
      holder.description.setText("");
    }
    if (option.getUpgradeprice() != null && !option.getUpgradeprice().isEmpty() && !option.getUpgradeprice().equals("0")) {
      holder.upgradeprice.setVisibility(View.VISIBLE);
      holder.upgradeprice.setText("अपना प्लान अपग्रेड करें");

      holder.upgrade_pricedetail.setVisibility(View.VISIBLE);
      holder.upgrade_pricedetail.setText("₹ " + option.getUpgradeprice());
    } else {
      holder.upgradeprice.setVisibility(View.GONE);
      holder.upgradeprice.setText("");

      holder.upgrade_pricedetail.setVisibility(View.GONE);
      holder.upgrade_pricedetail.setText("");
    }
    if(option.getPrice() !="") {
      // Handle RadioButton state and clicks
      holder.radioButton.setVisibility(View.VISIBLE);
      holder.radioButton.setChecked(selectedPosition == position);
    } else {
      holder.radioButton.setVisibility(View.GONE);
    }
    // RadioButton click listener
    holder.radioButton.setOnClickListener(v -> {
      selectedPosition = holder.getAdapterPosition(); // Update selected position
      notifyDataSetChanged(); // Refresh the list to update UI
      listener.onItemClick(option); // Trigger the onItemClick callback
      Log.d("SubscriptionAdapter", "RadioButton clicked for position: " + position);
    });
  }


  @Override
  public int getItemCount() {
    return options.size();
  }

  static class SubscriptionViewHolder extends RecyclerView.ViewHolder {
    TextView title, description, price, offerprice,upgradeprice,upgrade_pricedetail;
    RadioButton radioButton;

    public void bind(final PackageModel item, final OnItemClickListener listener) {
      itemView.setOnClickListener(v -> listener.onItemClick(item));
    }

    SubscriptionViewHolder(View itemView) {
      super(itemView);
      title = itemView.findViewById(R.id.tvSingleMovie);
      description = itemView.findViewById(R.id.tvSingleMovieDescription);
      price = itemView.findViewById(R.id.live_price);
      offerprice = itemView.findViewById(R.id.actual_price);
      upgradeprice = itemView.findViewById(R.id.upgrade_price);
      upgrade_pricedetail = itemView.findViewById(R.id.upgrade_price_detail);
      radioButton = itemView.findViewById(R.id.radio_option1);
    }
  }
}

