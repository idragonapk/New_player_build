package com.idragonpro.andmagnus.utility;

import android.app.Activity;


public interface UtilityInterface {

    void finishActivity(Activity activity);

}
