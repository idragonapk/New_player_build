Ads functionality done
